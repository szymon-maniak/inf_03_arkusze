function najechanie(id, img){
    document.getElementById(id).src = img;
}

function opuszczenie(id, img){
    document.getElementById(id).src = img;
}

function klik(id, img){
    document.getElementById(id).src = img;
    document.getElementById('duzy').src = img;
}